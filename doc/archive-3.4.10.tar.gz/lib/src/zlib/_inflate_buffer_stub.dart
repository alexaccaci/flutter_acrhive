List<int>? inflateBuffer_(List<int> data) {
  throw UnsupportedError('inflateBuffer requires html or io.');
}

bool useNativeZLib_() {
  return false;
}
