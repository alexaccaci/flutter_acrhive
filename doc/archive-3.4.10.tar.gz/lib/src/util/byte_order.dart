// enum ByteOrder
const int LITTLE_ENDIAN = 0;
const int BIG_ENDIAN = 1;
